#include <stdio.h>
#include <stdlib.h>

#include "readimage.h"
#include "HSV_RGB.h"
#include "brightness.h"
#include "debugmalloc.h"
#include "filters.h"


HSV** findedges(ImageParams const *imgdata, HSV  **HSVmatrix){
    double surround[8];
    double szele = 1;

    HSV** filteredHSV = (HSV**) malloc(imgdata->h * sizeof(HSV*));
    filteredHSV[0] = (HSV*) malloc(imgdata->w * imgdata->h * sizeof(HSV));
    for (int y = 1; y < imgdata->h; ++y)
        filteredHSV[y] = filteredHSV[0] + y * imgdata->w;


    if (filteredHSV == NULL)
        return NULL;

    for (int y = 0; y < imgdata->h; y++){
        for (int x = 0; x < imgdata->w; x++){



            // kep szeleinek lekezelese a tulindexeles elkerulese erdekeben
            /*if (y == 0){ //kep felso szele
                for (int i = 0; i<3; i++)
                    surround[i] = szele;
            }
            if (y == imgdata->h - 1){ //kep felso szele
                for (int j = 5; j<8; j++)
                    surround[j] = szele;
            }
            if (x == 0){
                surround[3] = szele;
            }
            else if (x == imgdata->w-1){
                surround[4] = szele;
            }
            else */
            if ((y != 0) && (x != 0) && (y != imgdata->h-1) && (x != imgdata->w-1) ){
                surround[0] = HSVmatrix[y-1][x-1].v;
                surround[1] = HSVmatrix[y-1][x].v;
                surround[2] = HSVmatrix[y-1][x+1].v;
                surround[3] = HSVmatrix[y][x-1].v;
                surround[4] = HSVmatrix[y][x+1].v;
                surround[5] = HSVmatrix[y+1][x-1].v;
                surround[6] = HSVmatrix[y+1][x].v;
                surround[7] = HSVmatrix[y+1][x+1].v;
            }
            else
                for (int i = 0; i < 8; i++)
                    surround[i] = szele;

            double sum = 0;
            for (int i = 0; i < 8; i++){
                sum+=surround[i];
            }
            filteredHSV[y][x].h = HSVmatrix[y][x].h;
            filteredHSV[y][x].s = 0;//HSVmatrix[y][x].s;
            filteredHSV[y][x].v = ((-8)*HSVmatrix[y][x].v + sum);

        }//end for j
    }//end for i
    return filteredHSV;
}
