#ifndef FILTERS_H
#define FILTERS_H

HSV** findedges(ImageParams const *imgdata, HSV  **HSVmatrix);

#endif

