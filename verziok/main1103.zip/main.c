#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include  <ctype.h> //az ispsace function miatt kell a fajl olvasasakor - egyelore nem hasznalom, mert nem azonositja a \n-t whitespacekent

typedef enum MainMenu{
    exitprog,
    contrast,
    brightness,
    blur,
    edges
};

typedef enum SubMenu{
    quit,
    saveas,
    save
};

typedef struct ImageParams{
    int h;
    int w;
    int depth;
}ImageParams;


int readfile2(char *filename){
    int datacount = 0;
    int count = 0;
    bool iscomment = false;
    bool isnum = false;
    int numstart, numend;
    int imgdataidx[3];

    FILE *inputfile;
    char* puf;

    inputfile = fopen(filename, "rb");
    printf("The selected file is %s\n", filename);
    if (inputfile == NULL){
        printf("Error opening file");
        return 1; //1-es hibakod
    }
    else
        printf("File opened successfully\n");

   // while (puf[count] !=EOF){
    while (datacount < 3){
        fread(&puf[count], sizeof(char), 1, inputfile);

        //filetipus beazonositasa
        if (count==1){
            if (puf[0] != 'P' || puf[1] !='6'){
                printf("Error: not a valid *.ppm file (identifier = %c%c)\n", puf[0], puf[1]);
                return 2; //2-es hibakod
            }
            else
                printf("Successful identification as valid *.ppm file (identifier = %c%c)\n", puf[0], puf[1]);
        }

        //komment szekcio beazonositasa
        if (puf[count] == '#'){
            iscomment = true;
            if (iscomment)
                printf("Here is the COMMENT\n");
        }
        if (iscomment && puf[count] == '\n'){
             iscomment = false;
             printf(" whitespace itt\n");
             if (!iscomment)
                printf("NO COMMENT\n");
        }

        //magassag, szelesseg, bitmelyseg adatok kinyerese karakterkent

        if (!iscomment && (isdigit(puf[count])!=0) && (!isnum) && count >1){
            numstart = count;
            isnum = true;
            printf("numstart = %d\n", numstart);
            printf("puf[numstart] = %d\n", puf[numstart]);

            imgdataidx[datacount] = count;
            printf("datacount = %d, imgdataidx = %d\n", datacount, imgdataidx[datacount]);
        }



        if (isnum && (puf[count] == ' ' || puf[count] == '\n')){
                numend = count;
                printf("numend = %d\n", numend);
                printf("puf[numend] = %d\n", puf[numend]);
                isnum = false;
                ++datacount;
        }
    ++count;
    }
    puf[count]='\0';
    printf("\n");
    printf("beolvasva: %s", puf);


    fclose(inputfile);
    printf("closed\n");

    return 0;



}

void readfilename(char *filename){
    printf("Please type in the filename of the image to modify. it should be a *.ppm file.");
    scanf("%s", filename);
}

void displaymain(){
    printf("Please choose an option!\n");
    printf("0 EXIT\n");
    printf("1 Modify contrast\n");
    printf("2 Modify brightness\n");
    printf("3 Blur image\n");
    printf("4 Find edges\n");
}

enum MainMenu selectmain(){

    int selected;
    scanf("%d", &selected);
     while (selected < 0 || selected > 4){
        printf("Error: you selected %d - no such option.\nPlease select 0..4 from the menu below\n", selected);
        displaymain();
        scanf("%d", &selected);
     }
     return selected;
}


//int datacount = 0; // ???????ha beteszem lok�lisba, nem fut vegig a program!!! ??
int readfile(char *filename, char *puf){

    int count = 0;
    bool iscomment = false;
    bool isnum = false;
    int numstart, numend;
    int imgdataidx[3];
    int datacount = 0; //short-tal nics gond, intk�nt nem fut v�gig ?!?!
    int h, w, d;
    FILE *inputfile;
    //char* puf;

    inputfile = fopen(filename, "rb");
    printf("The selected file is %s\n", filename);
    if (inputfile == NULL){
        printf("Error opening file");
        return 1; //1-es hibakod
    }
    else
        printf("File opened successfully\n");

   // while (puf[count] !=EOF){
    while (datacount < 3){
        fread(&puf[count], sizeof(char), 1, inputfile);

        //filetipus beazonositasa
        if (count==1){
            if (puf[0] != 'P' || puf[1] !='6'){
                printf("Error: not a valid *.ppm file (identifier = %c%c)\n", puf[0], puf[1]);
                return 2; //2-es hibakod
            }
            else
                printf("Successful identification as valid *.ppm file (identifier = %c%c)\n", puf[0], puf[1]);
        }

        //komment szekcio beazonositasa
        if (puf[count] == '#'){
            iscomment = true;
            if (iscomment)
                printf("Here is the COMMENT\n");
        }
        if (iscomment && puf[count] == '\n'){
             iscomment = false;
             printf(" whitespace itt\n");
             if (!iscomment)
                printf("NO COMMENT\n");
        }

        //magassag, szelesseg, bitmelyseg adatok kinyerese karakterkent

        if (!iscomment && (isdigit(puf[count])!=0) && (!isnum) && count >1){
            numstart = count;
            isnum = true;
            printf("numstart = %d\n", numstart);
            printf("puf[numstart] = %d\n", puf[numstart]);

            imgdataidx[datacount] = count;
            printf("datacount = %d, imgdataidx = %d\n", datacount, imgdataidx[datacount]);
        }



        if (isnum && (puf[count] == ' ' || puf[count] == '\n')){
                numend = count;
                printf("numend = %d\n", numend);
                printf("puf[numend] = %d\n", puf[numend]);
                isnum = false;
                ++datacount;
        }
    ++count;
    }
    puf[count]='\0';
    printf("\n");
    printf("beolvasva: %s", puf);

    char subbuff[5];
    memcpy( subbuff, &puf[imgdataidx[0]], 3 );
    subbuff[4] = '\0';
    printf("subbuf = %s\n", subbuff);
    sscanf(subbuff, "%d", &h);
    printf("h = %d\n", h);




    fclose(inputfile);
    printf("closed\n");


    return 0;
}

int main(){
    enum MainMenu option;
    //int option;
    int readfileresult;
    char *ppmheadline;
    displaymain();
    option = selectmain();
    printf("The selected option is: %d\n", option);
    //readfiletype("auto.ppm");

    readfileresult = readfile("C:\\Users\\terve\\Documents\\Mariann_BME\\Prog_lab\\NHF_V1\\NHFV1\\bin\\Debug\\auto.ppm", ppmheadline);
    printf("readfileresult = %d\n", readfileresult);


    return 0;
}
