#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>


#include "menu.h"
#include "readimage.h"
#include "HSV_RGB.h"
#include "debugmalloc.h"
#include "writeimage.h"
#include "filters.h"


void saveimage(ImageParams *imgdata, PixelData **matrix){
    enum SubMenu suboption;

    displaysubmenu();

    suboption = selectsubmenu();
    printf("The selected option is: %d\n", suboption);

    switch(suboption){
        case 0:{
            processimage(imgdata, matrix);
            break;
        }
        case 1: {
            writefile("PROBA.ppm", imgdata, matrix);
            break;
        }
        case 2: {
            writefile("PROBA.ppm", imgdata, matrix);
            break;
        }
    }
}


int processimage(ImageParams *imgdata, PixelData **matrix){
    enum MainMenu option;
    struct HSV **HSVmatrix;

    displaymain();
    option = selectmain();
    printf("The selected option is: %d\n", option);

    switch(option){
        case 0:{
            free(matrix[0]);
            free(matrix);
            exit(0);
        }
        case 1: {
            HSVmatrix = RGBtoHSV(imgdata, matrix);
            if (HSVmatrix == NULL){
                printf ("Error: HSV conversion failed!\n");
                return 2;
            }
            setcontrast(imgdata, HSVmatrix);
            HSVtoRGB(imgdata, HSVmatrix, matrix);
            free(HSVmatrix[0]);
            free(HSVmatrix);
            break;
        }
        case 2: {
            HSVmatrix = RGBtoHSV(imgdata, matrix);
            if (HSVmatrix == NULL){
                printf ("Error: HSV conversion failed!\n");
                return 2;
            }
            setbrightness(imgdata, HSVmatrix);
            HSVtoRGB(imgdata, HSVmatrix, matrix);
            free(HSVmatrix[0]);
            free(HSVmatrix);
            break;
        }
        case 3: {
            HSVmatrix = RGBtoHSV(imgdata, matrix);
            if (HSVmatrix == NULL){
                printf ("Error: HSV conversion failed!\n");
                return 2;
            }
            setsaturation(imgdata, HSVmatrix);
            HSVtoRGB(imgdata, HSVmatrix, matrix);
            free(HSVmatrix[0]);
            free(HSVmatrix);
            break;
        }
        case 4: {
            blurimage(imgdata, matrix);
            break;
        }
        case 5: {
            HSVmatrix = RGBtoHSV(imgdata, matrix);
            if (HSVmatrix == NULL){
                printf ("Error: HSV conversion failed!\n");
                return 2;
            }
            findedges(imgdata, HSVmatrix);
            HSVtoRGB(imgdata, HSVmatrix, matrix);
            free(HSVmatrix[0]);
            free(HSVmatrix);
            break;
        }
    }//end switch
    saveimage(imgdata, matrix);
    return 0;
}

void filenev_beker(char* filename){
    //char* name;
    //char const extension[4] = ".ppm";
    int i;
    printf("Please type in the filename of the image you wish to modify!\n");
    scanf("%s", filename);
    /*printf("filename bekerve = ");
    for (i = 0; filename[i] !='.'; ++i){
       name[i]=filename[i];
    }
    name[i] = "\0";*/
    //printf("%s", name);
   // printf("\n");
   /* strcat(name, extension);
    printf("%s", name);
    printf("\n");*/

}




int main(){
    struct PixelData **matrix;
    short readfileresult;
    ImageParams imgdata;
    char filename[100];
    bool onemore = false;
    char yesno;

    do{
    filenev_beker(filename);

    matrix = readfile(filename, &readfileresult, &imgdata);
    if (matrix != NULL){
        printf("Image loaded successfully\n");
        processimage(&imgdata, matrix);
    }
    else{
        printf("ERROR loading image\n");
        printf("errorcode = %d\n", readfileresult);
        return 1;
    }

    free(matrix[0]);
    free(matrix);

    printf("Would you like to process another image?\n");
    scanf(" %c", &yesno); //szokoz kell, kulonben atugorja. Az elozo entert karakternek veszi!


    if ((yesno == 'y') || (yesno == 'Y'))
        onemore = true;
    else
        onemore = false;

    }while(onemore);

    printf("end.\n");
    return 0;
}
