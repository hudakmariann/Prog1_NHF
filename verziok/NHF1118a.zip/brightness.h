#ifndef BRIGHTNESS_H
#define BRIGHTNESS_H

void setbrightness(ImageParams const *imgdata, HSV  **HSVmatrix);
void setsaturation(ImageParams const *imgdata, HSV  **HSVmatrix);

double maxval(ImageParams const *imgdata, const struct  HSV  **HSVmatrix);
double minval(ImageParams const *imgdata, const struct  HSV  **HSVmatrix);

void setcontrast(ImageParams const *imgdata, struct HSV  **HSVmatrix);

#endif
