#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include  <ctype.h> //az ispsace function miatt kell a fajl olvasasakor - egyelore nem hasznalom, mert nem azonositja a \n-t whitespacekent

typedef enum MainMenu{
    exitprog,
    contrast,
    brightness,
    blur,
    edges
};

typedef enum SubMenu{
    quit,
    saveas,
    save
};

typedef struct ImageParams{
    int h;
    int w;
    int depth;
}ImageParams;

void readfilename(char *filename){
    printf("Please type in the filename of the image to modify. it should be a *.ppm file.");
    scanf("%s", filename);
}

void displaymain(){
    printf("Please choose an option!\n");
    printf("0 EXIT\n");
    printf("1 Modify contrast\n");
    printf("2 Modify brightness\n");
    printf("3 Blur image\n");
    printf("4 Find edges\n");
}

enum MainMenu selectmain(){

    int selected;
    scanf("%d", &selected);
     while (selected < 0 || selected > 4){
        printf("Error: you selected %d - no such option.\nPlease select 0..4 from the menu below\n", selected);
        displaymain();
        scanf("%d", &selected);
     }
     return selected;
}

int datacount = 0;
int readfile(char *filename){
     bool iscomment = false;
    bool isnum = false;
    int numstart, numend;
    char num[3];
    char* numchar[3]; //3 elemu pointertomb karakterre
    //int numcharcount = 0;
    int imgdataidx[3];


    int count = 0;
    int h,w,d;


    ImageParams imgpar;
    FILE *inputfile;
    char* puf;

    inputfile = fopen(filename, "rb");
    printf("The selected file is %s\n", filename);
    if (inputfile == NULL){
        printf("Error opening file");
        //exit(1);
        return 1; //1-es hibakod
    }
    else
        printf("File opened successfully\n");
//filetipus beazonositasa
    //for (int i = 0; i < 3; ++i){




   // while (puf[count] !=EOF){
    while (datacount < 3){
        fread(&puf[count], sizeof(char), 1, inputfile);

        //filetipus beazonositasa
        if (count==1){
            if (puf[0] != 'P' || puf[1] !='6'){
                printf("Error: not a valid *.ppm file (identifier = %c%c)\n", puf[0], puf[1]);
                return 2; //2-es hibakod
            }
            else
                printf("Successful identification as valid *.ppm file (identifier = %c%c)\n", puf[0], puf[1]);
        }

        //komment szekcio beazonositasa
        if (puf[count] == '#'){
            iscomment = true;
            if (iscomment)
                printf("Here is the COMMENT\n");
        }
        if (iscomment && puf[count] == '\n'){
             iscomment = false;
             printf(" whitespace itt\n");
             if (!iscomment)
                printf("NO COMMENT\n");
        }

        //magassag, szelesseg, bitmelyseg adatok kinyerese karakterkent

        if (!iscomment && (isdigit(puf[count])!=0) && (!isnum) && count >1){
            numstart = count;
            isnum = true;
            printf("numstart = %d\n", numstart);
            printf("puf[numstart] = %d\n", puf[numstart]);


          //  num[0] = puf[numstart];

            //numchar[numcharcount] = &puf[count];
            //numcharcount++;

        }



        if (isnum && (puf[count] == ' ' || puf[count] == '\n')){
                numend = count;
                printf("numend = %d\n", numend);
                printf("puf[numend] = %d\n", puf[numend]);
                isnum = false;

                imgdataidx[datacount] = count;
                printf("datacount = %d, imgdataidx = %d\n", datacount, imgdataidx[datacount]);
                datacount++;

           // p = puf[numstart];
            //num[1] = puf[numend-1];



        }
        //num[0] =puf[numstart];

    ++count;
    }
    puf[count]='\0';
    printf("\n");
    printf("beolvasva: %s", puf);

   // for (int i = 0; i < 5; ++i){
       // printf("%c", *numchar[i]);}

    /*while (puf!=' ') {
        fread(&puf, sizeof(char), 1, inputfile);
        printf("%c", puf);
    }*/

    /*fscanf(inputfile, "%c", &filetypec);
    fscanf(inputfile, "%d", &filetyped);
    printf("%c\n",filetypec);
    printf("%d\n",filetyped);*/

fclose(inputfile);
}

int main(){
    enum MainMenu option;
    displaymain();
    option = selectmain();
    printf("The selected option is: %d\n", option);
    //readfiletype("auto.ppm");
    readfile("C:\\Users\\terve\\Documents\\Mariann_BME\\Prog_lab\\NHF_V1\\NHFV1\\bin\\Debug\\auto.ppm");

    return 0;
}
