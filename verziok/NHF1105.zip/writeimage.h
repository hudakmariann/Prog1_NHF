#ifndef WRITEIMAGE_H
#define WRITEIMAHE_H

char const* VERSION = "IMAGE EDITOR v1104.g";
void matrix_kiir(ImageParams const *imgdata, PixelData  **matrix);

#endif // WRITEIMAGE_H
