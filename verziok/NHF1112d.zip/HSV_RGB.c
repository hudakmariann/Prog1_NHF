#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "readimage.h"
#include "debugmalloc.h"
#include "HSV_RGB.h"



short minRGB(PixelData const pix){
    short rgb[3] = {pix.r, pix.g, pix.b};
    short min = 255;
    for (int i = 0; i<3; ++i){
        if (rgb[i] < min)
            min = rgb[i];
    }
    return min;
}

short maxRGB(PixelData const pix){
    short rgb[3] = {pix.r, pix.g, pix.b};
    short max = 0;
    for (int i = 0; i<3; ++i){
        if (rgb[i] > max)
            max = rgb[i];
    }
    return max;
}

// kepletek forrasa: https://www.had2know.org/technology/hsv-rgb-conversion-formula-calculator.html
HSV** RGBtoHSV(const ImageParams*  imgdata, const PixelData**  matrix){
    short min, max;
    HSV** HSVmatrix;
    short r, g, b; //segedvaltozok, a kod atlathatosaga, rovidites miatt vannak, amugy redundans
    const double PI =  3.1415926;

    /* foglal�s */
    HSVmatrix = (HSV**) malloc(imgdata->h * sizeof(HSV*));
    HSVmatrix[0] = (HSV*) malloc(imgdata->w * imgdata->h * sizeof(HSV));

    for (int y = 1; y < imgdata->h; ++y)
        HSVmatrix[y] = HSVmatrix[0] + y * imgdata->w;



    for (int i = 0; i < imgdata->h; i++){
        for (int j = 0; j < imgdata->w; j++){
            max = maxRGB(matrix[i][j]);
            min = minRGB(matrix[i][j]);
            HSVmatrix[i][j].v = max/255;
            r = matrix[i][j].r;
            g = matrix[i][j].g;
            b = matrix[i][j].b;

            if (max > 0)
                HSVmatrix[i][j].s = 1-min/max;
            else
                 HSVmatrix[i][j].s = 0;
            if (g > b || g == b)
                HSVmatrix[i][j].h = (180/PI)*(acos(r - 0.5*g - 0.5*b)/ (acos(sqrt(r*r + g*g + b*b -r*g - r*b - g*b))))  ;
            else
                HSVmatrix[i][j].h = 360 - ((180/PI)*(acos (r - 0.5*g - 0.5*b)/ (acos (sqrt(r*r + g*g + b*b -r*g - r*b - g*b)))));
        }//end for j
    }//end for i
    return HSVmatrix;
}


// kepletek forrasa: https://www.had2know.org/technology/hsv-rgb-conversion-formula-calculator.html
void HSVtoRGB(ImageParams const *imgdata, HSV const **HSVmatrix, PixelData** matrix){
    short max, min;
    double h, s, v; //segedvaltozok, csak a rovidebb es atlathatobb kod kedveert, hogy ne kelljen mindig kiirni a matrixot indexelve
    double z;

    for (int i = 0; i < imgdata->h; i++){
        for (int j = 0; j < imgdata->w; j++){
            max = maxRGB(matrix[i][j]);
            min = minRGB(matrix[i][j]);
            h = HSVmatrix[i][j].h;
            s = HSVmatrix[i][j].s;
            v = HSVmatrix[i][j].v;
            max = 255*v;
            min = max*(1-s);
            z = (max-min)*(1-abs(fmod((h/60), 2)-1)); //itt a leirasban mod van, de ez hulyeseg. ugy irja, hogy 2.25 mod 2 = 0.25

            if ((h == 0 || h > 0) && (h < 60)){
                matrix[i][j].r = max;
                matrix[i][j].g = z + min;
                matrix[i][j].b = min;
            }
            else
            if ((h > 60 || h == 60) && (h < 120)){
                matrix[i][j].r = z + min;
                matrix[i][j].g = max;
                matrix[i][j].b = min;
            }
            else
            if ((h > 120 || h == 120) && (h < 180)){
                matrix[i][j].r = min;
                matrix[i][j].g = max;
                matrix[i][j].b = z + min;
            }
            else
            if ((h > 180 || h == 180) && h < 240){
                matrix[i][j].r = min;
                matrix[i][j].g = z + min;
                matrix[i][j].b = max;
            }
            else
            if ((h > 240 || h == 240) && h < 300){
                matrix[i][j].r = z + min;
                matrix[i][j].g = min;
                matrix[i][j].b = max;
            }
            else
            if ((h > 300 || h == 300) && (h < 360 )){
                matrix[i][j].r = max;
                matrix[i][j].g = min;
                matrix[i][j].b = z + min;
            }
        }//end for j
    }//end for i

return 0;
}
