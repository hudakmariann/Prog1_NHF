#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "readimage.h"
#include "debugmalloc.h"
#include "HSV_RGB.h"



short minRGB(PixelData const pix){
    short rgb[3] = {pix.r, pix.g, pix.b};
    short min = 255;
    for (int i = 0; i<3; ++i){
        if (rgb[i] < min)
            min = rgb[i];
    }
    return min;
}

short maxRGB(PixelData const pix){
    short rgb[3] = {pix.r, pix.g, pix.b};
    short max = 0;
    for (int i = 0; i<3; ++i){
        if (rgb[i] > max)
            max = rgb[i];
    }
    return max;
}

// kepletek forrasa: https://www.had2know.org/technology/hsv-rgb-conversion-formula-calculator.html
HSV** RGBtoHSV(ImageParams const *imgdata, PixelData const **matrix){
    short min, max;
    HSV** HSVmatrix;
    short r, g, b; //segedvaltozok, a kod atlathatosaga, rovidites miatt vannak, amugy redundans

    /* foglal�s */
    HSVmatrix = (HSV**) malloc(imgdata->h * sizeof(HSV*));
    HSVmatrix[0] = (HSV*) malloc(imgdata->w * imgdata->h * sizeof(HSV));

    for (int y = 1; y < imgdata->h; ++y)
        HSVmatrix[y] = HSVmatrix[0] + y * imgdata->w;


    for (int i = 0; i < imgdata->h; i++){
        for (int j = 0; j < imgdata->w; j++){
            max = maxRGB(matrix[i][j]);
            min = minRGB(matrix[i][j]);
            HSVmatrix[i][j].v = max/255;
            r = matrix[i][j].r;
            g = matrix[i][j].g;
            b = matrix[i][j].b;

            if (max > 0)
                HSVmatrix[i][j].s = 1-min/max;
            else
                 HSVmatrix[i][j].s = 0;
            if (g > b || g == b)
                HSVmatrix[i][j].h = 1/(cos (r - 0.5*g - 0.5*b)/ (sqrt(r*r + g*g + b*b -r*g - r*b - g*b))  );
            else
                HSVmatrix[i][j].h = 360 - (1/(cos (r - 0.5*g - 0.5*b)/ (sqrt(r*r + g*g + b*b -r*g - r*b - g*b))));
        }//end for j
    }//end for i


// kepletek forrasa: https://www.had2know.org/technology/hsv-rgb-conversion-formula-calculator.html
void HSVtoRGB(ImageParams const *imgdata, HSV const **HSVmatrix, PixelData** matrix){
    short max, min;
    int h, s, v; //segedvaltozok, csak a rovidebb es atlathatobb kod kedveert, hogy ne kelljen mindig kiirni a matrixot indexelve
    int z;

    for (int i = 0; i < imgdata->h; i++){
        for (int j = 0; j < imgdata->w; j++){
            max = maxRGB(matrix[i][j]);
            min = minRGB(matrix[i][j]);
            h = HSVmatrix[i][j].h;
            s = HSVmatrix[i][j].s;
            v = HSVmatrix[i][j].v;
            max = 255*v;
            min = max*(1-s);
            z = (max-min)*(1-abs((h/60)%2-1));

            if ((h == 0 || h > 0) && (h < 60)){
                r = max;
                g = z + min;
                b = min;
            }
            else
            if ((h > 60 || h == 60) && (h < 120)){
                r = z + min;
                g = max;
                b = min;
            }
            else
            if ((h > 120 || h == 120) && (h < 180)){
                r = min;
                g = max;
                b = z + min;
            }
            else
            if ((h > 180 || h == 180) && h < 240){
                r = min;
                g = z + min;
            }
            else
            if ((h > 240 || h == 240) && h < 300){
                r = z + min;
                g = min;
                b = max;
            }
            else
            if ((h > 300 || h == 300) && h < 360){
                r = max;
                g = min;
                b = z + min;
            }

        }//end for j
    }//end for i

}




}
