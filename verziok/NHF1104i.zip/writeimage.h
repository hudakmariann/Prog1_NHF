#ifndef WRITEIMAGE_H
#define WRITEIMAHE_H

char const* VERSION = "Processed by IMAGE EDITOR v1104.g\n";
void matrix_kiir(ImageParams const *imgdata, PixelData const **matrix);

#endif // WRITEIMAGE_H
