#include <stdio.h>
#include <stdlib.h>

#include "readimage.h"
#include "writeimage.h"
#include "debugmalloc.h"



void writefile(char const *filename, ImageParams const *imgdata, PixelData const **matrix){
    FILE *outputfile;
    if (outputfile == NULL){
        printf("Error opening outputfile");
    }
    else
        printf("Outputfile opened.\n");
    int len = strlen(VERSION);
    outputfile  = fopen(filename, "wb");
    fwrite("P6\n", sizeof(char), 3, outputfile);
    fwrite("# ",sizeof (char), 2, outputfile);
    fwrite(VERSION, sizeof(char), len, outputfile);
    //fwrite(imgdata->w, sizeof(ImageParams),1, outputfile);
    /*fwrite(" ", sizeof(char), 1, outputfile);
    fwrite(imgdata->w, sizeof(ImageParams), 1,outputfile);
    fwrite("\n", sizeof(char), 1, outputfile);*/


fclose(outputfile);

}


void matrix_kiir(ImageParams const *imgdata, PixelData const **matrix){
    for (int i = 0; i < imgdata->h; i++){
        for (int j = 0; j < imgdata->w; j++){
            for (int k = 0; k<3; k++){
                 switch (k%3) {
                     case 0: {
                        printf(" [%d][%d].r=%d ",i, j, matrix[i][j].r);
                        break;
                     }
                     case 1: {
                        printf(" [%d][%d].g=%d ", i, j, matrix[i][j].g);
                        break;
                     }
                     case 2: {
                        printf(" [%d][%d].b=%d ", i, j, matrix[i][j].b);
                        break;
                     }
                }//end case
            }// end for k
            printf("\n");
        }//end for j
    printf ("\n");
    }//end for i

    printf("\n");
    printf(" a %d. sor %d-edik pixelenek g erteke = %d \n", 117, 51, matrix[117][51].r);
    free(matrix[0]);
    free(matrix);
}

