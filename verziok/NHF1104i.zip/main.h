#ifndef MAIN_H
#define MAIN_H

typedef enum MainMenu{
    exitprog,
    contrast,
    brightness,
    blur,
    edges
};

typedef enum SubMenu{
    quit,
    saveas,
    save
};

void displaymain();
enum MainMenu selectmain();
int main();


#endif // MAIN_H


