#include <stdio.h>
#include <stdlib.h>


#include "main.h"
#include "debugmalloc.h"
#include "readimage.h"

void displaymain(){
    printf("Please choose an option!\n");
    printf("0 EXIT\n");
    printf("1 Modify contrast\n");
    printf("2 Modify brightness\n");
    printf("3 Blur image\n");
    printf("4 Find edges\n");
}

enum MainMenu selectmain(){
    int selected;
    scanf("%d", &selected);
     while (selected < 0 || selected > 4){
        printf("Error: you selected %d - no such option.\nPlease select 0..4 from the menu below\n", selected);
        displaymain();
        scanf("%d", &selected);
     }
     return selected;
}

int main(){
    enum MainMenu option;
    int readfileresult;
    ImageParams imgdata;
    //char *filename = "C:\\Users\\terve\\Documents\\Mariann_BME\\Prog_lab\\NHF_V1\\NHFV1\\bin\\Debug\\auto2.ppm";
    char *filename = "auto.ppm";
    PixelData **matrix;

    displaymain();
    option = selectmain();
    printf("The selected option is: %d\n", option);
    matrix = readfile(filename, &readfileresult, &imgdata);
    if (matrix != NULL){
        printf("Image loaded successfully\n");
        //matrix_kiir(&imgdata, matrix);
        writefile("PROBA.txt", &imgdata, &matrix);
        free(matrix[0]);
        free(matrix);
    }
    else{
        printf("ERROR loading image\n");
        printf("errorcode = %d\n", readfileresult);
    }

    return 0;
}
