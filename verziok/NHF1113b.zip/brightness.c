#include <stdio.h>
#include <stdlib.h>

#include "readimage.h"
#include "HSV_RGB.h"
#include "brightness.h"
#include "debugmalloc.h"


void setbrightness(ImageParams const *imgdata, HSV  **HSVmatrix){
    float percent;
    printf("Please type in the factor of brightness change between -100 and +100.\n");
    scanf("%f", &percent);
    percent /=100;


     for (int i = 0; i < imgdata->h; i++){
        for (int j = 0; j < imgdata->w; j++){
        HSVmatrix[i][j].v = HSVmatrix[i][j].v*(1+percent);

        }//end for j
    }//end for i

}
