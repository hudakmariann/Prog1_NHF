#ifndef BRIGHTNESS_H
#define BRIGHTNESS_H

void setbrightness(ImageParams const *imgdata, HSV  **HSVmatrix);

#endif
