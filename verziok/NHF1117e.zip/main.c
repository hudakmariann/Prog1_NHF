#include <stdio.h>
#include <stdlib.h>
#include <bool.h>

#include "menu.h"
#include "readimage.h"
#include "HSV_RGB.h"
#include "debugmalloc.h"
#include "writeimage.h"
#include "filters.h"



int main(){
    PixelData **matrix;
    HSV **HSVmatrix;
    PixelData **filteredmatrix;
    enum MainMenu option;
    short readfileresult;
    ImageParams imgdata;
    char filename[100];

    printf("Please type in the fimename of the image you wish to modify!\n");
    scanf("%s", filename);


    matrix = readfile(filename, &readfileresult, &imgdata);
    if (matrix != NULL)
        printf("Image loaded successfully\n");
    else{
        printf("ERROR loading image\n");
        printf("errorcode = %d\n", readfileresult);
        return 1;
    }

    displaymain();
    option = selectmain();
    printf("The selected option is: %d\n", option);

    switch(option){
        case 0:{
            free(matrix[0]);
            free(matrix);
            exit(0);
        }
        case 1: {
             HSVmatrix = RGBtoHSV(&imgdata, matrix);
            if (HSVmatrix == NULL){
                printf ("Error: HSV conversion failed!\n");
                return 2;
            }
            setcontrast(&imgdata, HSVmatrix);
            HSVtoRGB(&imgdata, HSVmatrix, matrix);
            free(HSVmatrix[0]);
            free(HSVmatrix);
            break;
        }
        case 2: {
            HSVmatrix = RGBtoHSV(&imgdata, matrix);
            if (HSVmatrix == NULL){
                printf ("Error: HSV conversion failed!\n");
                return 2;
            }
            setbrightness(&imgdata, HSVmatrix);
            HSVtoRGB(&imgdata, HSVmatrix, matrix);
            free(HSVmatrix[0]);
            free(HSVmatrix);
            break;
        }
        case 3: {
            HSVmatrix = RGBtoHSV(&imgdata, matrix);
            if (HSVmatrix == NULL){
                printf ("Error: HSV conversion failed!\n");
                return 2;
            }
            setsaturation(&imgdata, HSVmatrix);
            HSVtoRGB(&imgdata, HSVmatrix, matrix);
            free(HSVmatrix[0]);
            free(HSVmatrix);
            break;
        }
        case 4: {
            filteredmatrix = blurimage(&imgdata, matrix);
            break;
        }
        case 5: {
            HSVmatrix = RGBtoHSV(&imgdata, matrix);
            if (HSVmatrix == NULL){
                printf ("Error: HSV conversion failed!\n");
                return 2;
            }
            findedges(&imgdata, HSVmatrix);
            HSVtoRGB(&imgdata, HSVmatrix, matrix);
            free(HSVmatrix[0]);
            free(HSVmatrix);
            break;
        }
    }//end switch

        writefile("PROBA.ppm", &imgdata, filteredmatrix);

        free(filteredmatrix[0]);
        free(filteredmatrix);
        free(matrix[0]);
        free(matrix);

printf("end.\n");
    return 0;
}
