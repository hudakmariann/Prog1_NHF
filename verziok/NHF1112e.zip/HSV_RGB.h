#ifndef HSV_RGB_H
#define HSV_RGB_H


typedef struct HSV{
    double h, s, v;
}HSV;


short minRGB(PixelData const pix);
short maxRGB(PixelData const pix);

HSV** RGBtoHSV(const ImageParams*  imgdata, const PixelData**   matrix);
void HSVtoRGB(ImageParams const *imgdata, HSV const **HSVmatrix, PixelData** matrix);


#endif
