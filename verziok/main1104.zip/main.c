#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include  <ctype.h> //az ispsace function miatt kell a fajl olvasasakor - egyelore nem hasznalom, mert nem azonositja a \n-t whitespacekent

typedef enum MainMenu{
    exitprog,
    contrast,
    brightness,
    blur,
    edges
};

typedef enum SubMenu{
    quit,
    saveas,
    save
};

typedef struct ImageParams{
    int w;
    int h;
    int d;
}ImageParams;



void readfilename(char *filename){
    printf("Please type in the filename of the image to modify. it should be a *.ppm file.");
    scanf("%s", filename);
}

void displaymain(){
    printf("Please choose an option!\n");
    printf("0 EXIT\n");
    printf("1 Modify contrast\n");
    printf("2 Modify brightness\n");
    printf("3 Blur image\n");
    printf("4 Find edges\n");
}

enum MainMenu selectmain(){
    int selected;
    scanf("%d", &selected);
     while (selected < 0 || selected > 4){
        printf("Error: you selected %d - no such option.\nPlease select 0..4 from the menu below\n", selected);
        displaymain();
        scanf("%d", &selected);
     }
     return selected;
}

int readfile(char *filename){
    int datacount = 0; //short-tal nics gond, intk�nt nem fut v�gig ?!?!
    char szam[10];
    FILE *inputfile;
    char c;
    bool valid = false;
    char filetype[3];
    char size[10];
    char depth[5];
    ImageParams imgdata;

    inputfile = fopen(filename, "rb");
    printf("The selected file is %s\n", filename);
    if (inputfile == NULL){
        printf("Error opening file");
        return 1; //1-es hibakod
    }
    else
        printf("File opened successfully\n");

   for (int i = 0; i<3; ++i){
       fread(&filetype[i], sizeof(char), 1, inputfile);
   }
   if (filetype[0] != 'P' || filetype[1] !='6'){
        printf("Error: not a valid *.ppm file (identifier = %c%c)\n", filetype[0], filetype[1]);
        return 2; //2-es hibakod
    }
    else
        printf("Successful identification as valid *.ppm file (identifier = %c%c)\n", filetype[0], filetype[1]);

    //comment kiszurese
    fread(&c, sizeof(char), 1, inputfile);
    printf("c = %c",c);
    if (c == '#'){
        //printf("comment = ");
        int i = 0;
        while (c != '\n')
            fread(&c, sizeof(char), 1, inputfile);
    }


     size[0] = c; //ha nem volt komment, a kep  merete mar itt kezodik, ezert be kell irni a size tombbe. Ha volt, akkor a \n kerul a size tomb elejere, de azt a sscanf ugysem fogja szamkent beolvasni, ugyhogy nem baj.
     //printf ("size[0] = %c", size[0]);


    // kep meretenek beolvasasa
    fread(&c, sizeof(char), 1, inputfile);
     if (isdigit(c)){
        size[1] = c;
        printf("size[1] = %c\n",size[1]);
        int i = 2;
        while (c != '\n'){
            fread(&c, sizeof(char), 1, inputfile);
            size[i] = c;
           // printf("%c",size[i]);
            i++;
        }
    sscanf(size, "%d %d", &imgdata.h, &imgdata.w);

    printf("width = %d, height = %d\n", imgdata.w, imgdata.h);
    }
    else{
        printf("Error: file contains invalid resolution data\n");
        return 3;
    }

    //bitmelyseg beolvasasa
     fread(&c, sizeof(char), 1, inputfile);
     if (isdigit(c)){
        depth[0] = c;
       // printf("%c",depth[0]);
        int j = 1;
        while (c != '\n'){
            fread(&c, sizeof(char), 1, inputfile);
            depth[j] = c;
           // printf("%c",depth[i]);
            j++;
        }
        sscanf(depth, "%d", &imgdata.d);

        printf("bitdepth = %d\n", imgdata.d);
    }
    else{
        printf("Error: file contains invalid color data\n");
        return 4;
    }

fclose(inputfile);
//printf("closed\n");
return 0;
}




int main(){
    enum MainMenu option;
    int readfileresult;

    displaymain();
    option = selectmain();
    printf("The selected option is: %d\n", option);
    readfileresult = readfile("C:\\Users\\terve\\Documents\\Mariann_BME\\Prog_lab\\NHF_V1\\NHFV1\\bin\\Debug\\auto2.ppm");
    printf("readfileresult = %d\n", readfileresult);


    return 0;
}
