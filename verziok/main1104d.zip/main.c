#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include  <ctype.h> //az ispsace function miatt kell a fajl olvasasakor - egyelore nem hasznalom, mert nem azonositja a \n-t whitespacekent

typedef enum MainMenu{
    exitprog,
    contrast,
    brightness,
    blur,
    edges
};

typedef enum SubMenu{
    quit,
    saveas,
    save
};



typedef struct PixelData{
    short r, g, b;
}PixelData;



typedef struct ImageParams{
    int w;
    int h;
    int d;
}ImageParams;


void readfilename(char *filename){
    printf("Please type in the filename of the image to modify. it should be a *.ppm file.");
    scanf("%s", filename);
}

void displaymain(){
    printf("Please choose an option!\n");
    printf("0 EXIT\n");
    printf("1 Modify contrast\n");
    printf("2 Modify brightness\n");
    printf("3 Blur image\n");
    printf("4 Find edges\n");
}

enum MainMenu selectmain(){
    int selected;
    scanf("%d", &selected);
     while (selected < 0 || selected > 4){
        printf("Error: you selected %d - no such option.\nPlease select 0..4 from the menu below\n", selected);
        displaymain();
        scanf("%d", &selected);
     }
     return selected;
}

int readfile(char *filename){

    FILE *inputfile;
    char c;
    char filetype[3];
    char size[10];
    char depth[5];
    ImageParams imgdata;
    PixelData *pixel;

    inputfile = fopen(filename, "rb");
    printf("The selected file is %s\n", filename);
    if (inputfile == NULL){
        printf("Error opening file");
        return 1; //1-es hibakod
    }
    else
        printf("File opened successfully\n");

   for (int i = 0; i<3; ++i){
       fread(&filetype[i], sizeof(char), 1, inputfile);
   }
   if (filetype[0] != 'P' || filetype[1] !='6'){
        printf("Error: not a valid *.ppm file (identifier = %c%c)\n", filetype[0], filetype[1]);
        return 2; //2-es hibakod
    }
    else
        printf("Successful identification as valid *.ppm file (identifier = %c%c)\n", filetype[0], filetype[1]);

    //comment kiszurese
    fread(&c, sizeof(char), 1, inputfile);
    //printf("c = %c",c);
    if (c == '#'){
        int i = 0;
        while (c != '\n')
            fread(&c, sizeof(char), 1, inputfile);
    }

// kep meretenek beolvasasa
     size[0] = c; //ha nem volt komment, a kep  merete mar itt kezodik, ezert be kell irni a size tombbe. Ha volt, akkor a \n kerul a size tomb elejere, de azt a sscanf ugysem fogja szamkent beolvasni, ugyhogy nem baj.
     fread(&c, sizeof(char), 1, inputfile);
     if (isdigit(c)){
        size[1] = c;
        int i = 2;
        while (c != '\n'){
        //while (!isspace(c)){
            fread(&c, sizeof(char), 1, inputfile);
            size[i] = c;
            i++;
        }

    sscanf(size, "%d %d", &imgdata.w, &imgdata.h);

    printf("width = %d, height = %d\n", imgdata.w, imgdata.h);
    }
    else{
        printf("Error: file contains invalid resolution data\n");
        return 3;
    }

    //bitmelyseg beolvasasa
     fread(&c, sizeof(char), 1, inputfile);
     if (isdigit(c)){
        depth[0] = c;
        int j = 1;
        while (c != '\n'){
         //while (!isspace(c)){
            fread(&c, sizeof(char), 1, inputfile);
            depth[j] = c;
            j++;
        }
        sscanf(depth, "%d", &imgdata.d);
        printf("bitdepth = %d\n", imgdata.d);
        //printf("c = %c", c);
    }
    else{
        printf("Error: file contains invalid color data\n");
        return 4;
    }


    //pixel adatok beolvasasa a heap-re

/*
    pixel = (PixelData*)malloc(imgdata.w * imgdata.h * sizeof(PixelData));
    if (!pixel) {
         fprintf(stderr, "Unable to allocate memory\n");
         return 5;
    }

    unsigned char p;
    short v;
    for (int i = 0; i < imgdata.h; i++){
        for (int j = 0; j < imgdata.w; j++){
             fread(&p,  sizeof(unsigned char), 1, inputfile) ;
             v = (short) p;
             switch (i*j%3) {
                 case 0: {
                    pixel[i*j].r = v;
                    printf(" r=%d ", pixel[i*j].r);
                    break;
                 }
                 case 1: {
                    pixel[i*j].g = v;
                    printf(" g=%d ", pixel[i*j].g);
                    break;
                 }
                 case 2: {
                    pixel[i*j].b = v;
                    printf(" b=%d ", pixel[i*j].b);
                    break;
                 }
            } //end case
        } //end for j
    printf ("\n");
    } //end for i

free(pixel);

*/

PixelData **matrix;
    unsigned char p;
    short v;

/* foglal�s */
    matrix = (PixelData**) malloc(imgdata.h * sizeof(PixelData*));
    matrix[0] = (PixelData*) malloc(imgdata.w * imgdata.h * sizeof(PixelData));
    for (int y = 1; y < imgdata.h; ++y)
        matrix[y] = matrix[0] + y * imgdata.w;

    /* haszn�lat */
    for (int i = 0; i < imgdata.h; i++){
        for (int j = 0; j < imgdata.w; j++){
            for (int k = 0; k<3; k++){
                 fread(&p,  sizeof(unsigned char), 1, inputfile) ;
                 v = (short) p;
                 switch (k%3) {
                     case 0: {
                        matrix[i][j].r = v;
                        printf(" [%d][%d].r=%d ",i, j, matrix[i][j].r);
                        break;
                     }
                     case 1: {
                        matrix[i][j].g = v;
                        printf(" [%d][%d].g=%d ", i, j, matrix[i][j].g);
                        break;
                     }
                     case 2: {
                        matrix[i][j].b = v;
                        printf(" [%d][%d].b=%d ", i, j, matrix[i][j].b);
                        break;
                     }
                }//end case
            }// end for k
            printf("\n");
        }//end for j
    printf ("\n");
    }//end for i

    printf("\n");

    printf(" a %d. sor %d-edik pixelenek g erteke = %d \n", 117, 51, matrix[117][51].r);


    /* felszabad�t�s */
    free(matrix[0]);
    free(matrix);



fclose(inputfile);
printf("closed\n");

return 0;
}




int main(){
    enum MainMenu option;
    int readfileresult;

    displaymain();
    option = selectmain();
    printf("The selected option is: %d\n", option);
    readfileresult = readfile("C:\\Users\\terve\\Documents\\Mariann_BME\\Prog_lab\\NHF_V1\\NHFV1\\bin\\Debug\\auto2.ppm");
    printf("readfileresult = %d\n", readfileresult);


    return 0;
}
